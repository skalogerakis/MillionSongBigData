File Overview

Million_Song_Dataset_Paper.pdf: is the requested report in a paper format

dependencies.sh: is the file used to install the required
dependencies in AWS machines

Useful_commands.txt: contains useful commands for quick aws deployment

DeploymentFiles directory: contains some of the different efforts to deploy in AWS environment. This code is very messy and contains files with failed attempts to tackle problems encounted at AWS. Included for completeness reasons. To evaluate the final code check CleanFiles directory.

CleanFiles directory: contains the Final implementation files, polished with added comments
