#!/bin/bash
sudo python3 -m pip install tables
sudo python3 -m pip install numpy
sudo python3 -m pip install h5df
sudo python3 -m pip install scikit-learn
sudo python3 -m pip install pandas
sudo python3 -m pip install matplotlib
sudo python3 -m pip install seaborn
sudo python3 -m pip install boto3